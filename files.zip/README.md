# LeetCode Obsidian CLI (Bubble Tea + huh)

A terminal UI for tracking LeetCode spaced-repetition review in an Obsidian
vault, built with [Bubble Tea](https://github.com/charmbracelet/bubbletea),
[huh](https://github.com/charmbracelet/huh), and
[Lip Gloss](https://github.com/charmbracelet/lipgloss).

This is a rewrite of the original single-file `bufio`-based CLI, split into
the module layout described in your plan.

## File structure

```
leetcode-cli/
├── go.mod / go.sum
├── main.go     # flags, vault dir setup, launches the Bubble Tea program
├── model.go    # Problem struct, state machine, Init/Update/View, styles
├── vault.go    # markdown frontmatter parsing/writing, vault-level stats
├── logic.go    # calculateNextReview — pure spaced-repetition math
└── forms.go    # huh.Form builders: new problem, review rating, lookup
```

## How it fits together

- `model.go` owns a `sessionState` enum (`stateMenu`, `stateNewProblem`,
  `stateReviewForm`, `stateSpecificInput`, `stateDone`). The top-level
  `Update` handles menu keypresses itself, and for every other state
  forwards the incoming `tea.Msg` straight into the active `huh.Form`'s
  `Update`, since `huh.Form` implements `tea.Model` natively.
- When a form's `.State` flips to `huh.StateCompleted`, the model reads the
  bound answers (`newProblemAnswers`, `confidence`, `specificNum`), does the
  file I/O via `vault.go`, and transitions state.
- `q` / `Esc` inside a form triggers `huh.StateAborted`, which just returns
  to the menu without saving.
- The "Review Due Problems" and "Review Specific Problem" flows share the
  same `startReview` / `reviewForm` / `saveReview` machinery — the only
  difference is how `m.dueFiles` gets populated (today's due list vs. a
  single looked-up file).

## Build & run

```bash
go mod tidy   # only needed once, to fetch bubbletea/huh/lipgloss
go build -o leetcode-cli .
./leetcode-cli -vault "/home/joshua/Second-Brain/02 - Fleeting/Leetcode"
```

> **Note on `go.mod`:** this environment has no route to `golang.org`
> (only `github.com`), so `go.mod` includes `replace` directives that point
> `golang.org/x/sys`, `x/sync`, `x/text`, and `x/term` at their official
> GitHub mirrors instead of the golang.org vanity import path. This was
> required to get `go mod tidy` working sandboxed and verified — it's
> harmless to keep on a normal machine with full internet access, or you
> can delete the `replace (...)` block at the bottom of `go.mod` and run
> `go mod tidy` again if you'd rather resolve them the standard way.

Verified in this environment: `go build` and `go vet` both pass cleanly
with zero errors. (I couldn't run the interactive TUI itself here since
Bubble Tea needs a real `/dev/tty`, which this sandbox doesn't expose —
run it in your own terminal.)

## Controls

- **Main menu:** `1` new problem, `2` review due, `3` review specific, `0` quit
- **Inside any form:** arrow keys / `j`/`k` to move between options, `Enter`
  to confirm a field or select an option, `Tab`/`Shift+Tab` between fields,
  `Esc` to abort back to the menu
- **After a save/review-session screen:** any key returns to the menu
- **Anywhere:** `Ctrl+C` quits immediately

## Extending it

- Add more confidence granularity or a 5th option → just add another
  `huh.NewOption` in `reviewForm` (forms.go) and a `case` in
  `calculateNextReview` (logic.go).
- Want a scrollable list instead of one-at-a-time review? Swap
  `stateReviewForm`'s single form for a `bubbles/list` model that shows
  `m.dueFiles` and drills into `startReview` per selection.
- Want colors to match your terminal theme? Adjust the `lipgloss.Color(...)`
  values at the top of `model.go`, or swap `huh.ThemeCharm()` in `forms.go`
  for `huh.ThemeDracula()`, `huh.ThemeBase16()`, etc.
