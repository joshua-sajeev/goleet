package main

import (
	"flag"
	"fmt"
	"os"

	tea "github.com/charmbracelet/bubbletea"
)

func main() {
	defaultPath := "/home/joshua/Second-Brain/02 - Fleeting/Leetcode"
	vaultDir := flag.String("vault", defaultPath, "Path to Obsidian LeetCode directory")
	flag.Parse()

	if err := ensureVaultDir(*vaultDir); err != nil {
		fmt.Printf("Failed to create/verify vault directory: %v\n", err)
		os.Exit(1)
	}

	p := tea.NewProgram(initialModel(*vaultDir), tea.WithAltScreen())
	if _, err := p.Run(); err != nil {
		fmt.Printf("Error running program: %v\n", err)
		os.Exit(1)
	}
}
